# kube
kubernetes　work node 
#add work node bash kube-work.sh
